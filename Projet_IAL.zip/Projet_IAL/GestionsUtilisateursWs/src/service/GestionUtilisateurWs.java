package service;

import java.util.ArrayList;

import javax.jws.WebService;

import dao.AccesBD;
import domaine.Utilisateur;

@WebService
public class GestionUtilisateurWs {

    
    private AccesBD bd = new AccesBD();
    
    public void ajoutUtilisateur(String login, String password, String profil) {
    	bd.ajouterUtilisateur(login, password,profil);
    }
    
    public void modifieUtilisateur(int id,String login, String password,String profil) {
    	bd.modifierUtilisateur(id,login, password,profil);
    }
    
    public void supprimeUtilisateur(int id) {
    	bd.supprimerUtilisateur(id);
    }
    
    public ArrayList<Utilisateur> listUtilisateur(){
    	ArrayList<Utilisateur> listes = bd.listerUtilisateur();
    return listes;
    }
    
    public boolean authentification(String login, String password) {
    	return bd.authentification(login, password);
    }
    
    public String getProfil(String login, String password) {
    	return bd.getProfil(login, password);
    }
}
