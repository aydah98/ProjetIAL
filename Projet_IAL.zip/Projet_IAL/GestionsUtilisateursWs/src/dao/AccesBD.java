package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import domaine.Utilisateur;


public class AccesBD {
	private Connection con=null;
	private PreparedStatement st=null;
    private ResultSet rs=null;
    
    public AccesBD()
    {
 	   try
        {
 		   //MySQL5
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/actualites","bousso","passer");
            

        }
        catch(Exception ex)
        {
            System.out.println("!!!!"+ex.getMessage());
        }

    }
    
    
    public void ajouterUtilisateur(String login, String password, String profil)
    {
    	Utilisateur u = new Utilisateur();
    	u.setLogin(login);
    	u.setPassword(password);
    	u.setProfil(profil);
 	   try
 	   {
 		   st= con.prepareStatement("insert into users(login,password,profil) values(?,?,?)");
            
            st.setString(1,u.getLogin());
            st.setString(2,u.getPassword());
            st.setString(3,u.getProfil());
            st.executeUpdate();
             
 	   }
 	   catch(Exception ex)
        {
            System.out.println("!!!!"+ex.getMessage());
        }

    }
    public void modifierUtilisateur(int id, String login, String password, String profil)
    {
    	Utilisateur u = new Utilisateur();
    	u.setLogin(login);
    	u.setPassword(password);
    	u.setProfil(profil);
 	   try
 	   {
 		   st= con.prepareStatement("update users set login=? , password=? , profil=? where id=? ");
            st.setString(1,u.getLogin());
            st.setString(2,u.getPassword());
            st.setString(3,u.getProfil());
            st.setInt(4,id);
            st.executeUpdate();
             
 	   }
 	   catch(Exception ex)
        {
            System.out.println("!!!!"+ex.getMessage());
        }

    }
    
    
    public void supprimerUtilisateur(int id)
    {

 	   try
 	   {
 		   st= con.prepareStatement("delete from users where id=?");
            st.setInt(1,id);
            st.executeUpdate();
             
 	   }
 	   catch(Exception ex)
        {
            System.out.println("!!!!"+ex.getMessage());
        }
   
    }
    
    public ArrayList<Utilisateur> listerUtilisateur()
    {
 	   ArrayList <Utilisateur> liste= new ArrayList <Utilisateur>();
 	   try
 	   {
 		   st =con.prepareStatement("select * from users");
            rs=st.executeQuery();
            while(rs.next())
            {
             int id=rs.getInt("id");
             String login=rs.getString("login");
             String password=rs.getString("password");
             String profil = rs.getString("profil");
             Utilisateur u = new Utilisateur();
             u.setId(id);
             u.setLogin(login);
             u.setPassword(password);
             u.setProfil(profil);
             liste.add(u);
             }
           
 	   }
 	   catch(Exception ex)
        {
            System.out.println("!!!!"+ex.getMessage());
        }
 	   return liste;
    }
    
    public boolean authentification(String login, String password)
    {
    	
 	   try
 	   {
 		   st= con.prepareStatement("select * from users");
            rs=st.executeQuery();
            while(rs.next())
            {
            	 if(login.equals(rs.getString("login")) && password.equals(rs.getString("password")))
            		 return true;
             }
             
 	   }
 	   catch(Exception ex)
        {
            System.out.println("!!!!"+ex.getMessage());
        }
    	return false;
    }
    
    public String getProfil(String login, String password)
    {
    	
 	   try
 	   {
 		   st= con.prepareStatement("select * from users where login=? and password=?");
 		   st.setString(1,login);
 		   st.setString(2,password);
            rs=st.executeQuery();
            while(rs.next())
            {
            	 if(login.equals(rs.getString("login")) && password.equals(rs.getString("password")))
            		 return rs.getString("profil");
             }
             
 	   }
 	   catch(Exception ex)
        {
            System.out.println("!!!!"+ex.getMessage());
        }
    	return "";
    }
}
