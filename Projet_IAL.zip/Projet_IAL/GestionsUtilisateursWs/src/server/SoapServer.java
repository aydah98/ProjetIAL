package server;

import javax.xml.ws.Endpoint;

import service.GestionUtilisateurWs;

public class SoapServer {
public static void main(String[] args) {
		
		String url = "http://localhost:8080/";
		Endpoint.publish(url, new GestionUtilisateurWs());
		System.out.println("le serveur est à l'ecoute sur : "+url);
		System.out.println("le fichier wsdl se trouve sur ce lien : "+url+"GestionUtilisateurWs?wsdl");

	}
}
