from zeep import Client

print("entrer votre login : ")
login = input()
login = str(login)
print("entrer votre password: ")
password = input()
password = str(password)
client = Client(wsdl="http://localhost:8080/GestionUtilisateurWs?wsdl")

verifier = client.service.authentification(login,password)


if(verifier):
	profil=client.service.getProfil(login, password);
	if(profil == "admin"):
		print("bienvenue dans la partie Gestion des Utilisateurs:")
		while True:
			print("0 : ajouter utilisateur")
			print("1 : modifier utilisateur")
			print("2 : supprimer utilisateur")
			print("3 : lister utilisateur")
			print("4 : quitter")
			choix = input()
			choix = int(choix)
			if choix == 0:
				print("entrer login : ")
				login = input()
				print("entrer password: ")
				password = input()
				print("entrer profil: ")
				profil = input()
				login = str(login)
				password = str(password)
				profil = str(profil)

				client.service.ajoutUtilisateur(login,password,profil)
			if choix == 1:
				print("entre l'id de l'utilisateur que tu veux modifier : ")
				id1 = input()
				print("entrer nouveau login : ")
				login = input()
				print("entrer nouveau password: ")
				password = input()
				print("entrer nouveau profil: ")
				profil = input()
				id1=int(id1)
				login = str(login)
				password = str(password)
				profil = str(profil)
				client.service.modifieUtilisateur(id1, login,password,profil)
			if choix == 2:
				print("entre l'id de l'utilisateur que tu veux supprimer : ")
				id1 = input()
				id1=int(id1)
				client.service.supprimeUtilisateur(id1)
			if choix == 3:
				print("liste des utilisateurs : ")
				listes = client.service.listUtilisateur()
				for cle in listes:
					print("----------------------------------------")
					for cle2 in cle:
						if(cle2 == "password"):
							continue
						else:
	  						print(cle2, " : " , cle[cle2])
				print("----------------------------------------")
			if choix == 4:
				break
	else:
		print("Vous n'etes pas admin")
else:
	print("login ou password incorrect!!!!!!!")




