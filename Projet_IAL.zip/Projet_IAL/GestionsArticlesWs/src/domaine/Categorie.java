package domaine;

public class Categorie {
	private Integer idCat;
	private String libelle;
	
	public Integer getIdCat() {
		return idCat;
	}
	public Categorie() {}
	
	public Categorie(Integer idCat, String libelle) {
		super();
		this.idCat = idCat;
		this.libelle = libelle;
	}
	public void setIdCat(Integer idCat) {
		this.idCat = idCat;
	}
	public String getLibelle() {
		return libelle;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	
	
}
