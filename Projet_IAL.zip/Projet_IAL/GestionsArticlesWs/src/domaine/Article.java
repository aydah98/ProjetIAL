package domaine;

import java.util.Date;

public class Article {
	private Integer id;
	private String titre;
	private String contenu;
	private Integer categorie;
	private Date dateCreation;
	private Date dateModification;

	public Article() {}

	public Article(Integer id, String titre, String contenu, Integer categorie, Date dateCreation,
			Date dateModification) {
		super();
		this.id = id;
		this.titre = titre;
		this.contenu = contenu;
		this.categorie = categorie;
		this.dateCreation = dateCreation;
		this.dateModification = dateModification;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public String getContenu() {
		return contenu;
	}

	public void setContenu(String contenu) {
		this.contenu = contenu;
	}

	public Integer getCategorie() {
		return categorie;
	}

	public void setCategorie(Integer categorie) {
		this.categorie = categorie;
	}

	public Date getDateCreation() {
		return dateCreation;
	}

	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
	}

	public Date getDateModification() {
		return dateModification;
	}

	public void setDateModification(Date dateModification) {
		this.dateModification = dateModification;
	}
	
	
	
	
}
