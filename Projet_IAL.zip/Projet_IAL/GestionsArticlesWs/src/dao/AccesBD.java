package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import domaine.*;

public class AccesBD {

	private Connection con=null;
	private PreparedStatement st=null;
    private ResultSet rs=null;
    
    public AccesBD()
    {
 	   try
        {
 		   //MySQL5
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mglsi_news","bousso","passer");

        }
        catch(Exception ex)
        {
            System.out.println("!!!!"+ex.getMessage());
        }

    }
    
    public ArrayList<Article> listArticles(){
    	
    	ArrayList<Article> liste = new ArrayList<Article>();
    	try
  	   {
  		   st =con.prepareStatement("select * from Article");
             rs=st.executeQuery();
             while(rs.next())
             {
              int id=rs.getInt("id");
              String titre=rs.getString("titre");
              String contenu=rs.getString("contenu");
              Integer cat =  rs.getInt("categorie");
              Date dateCrea = rs.getDate("dateCreation");
              Date dateModif = rs.getDate("dateModification");
              Article a = new Article(id, titre, contenu, cat, dateCrea, dateModif);
              
              liste.add(a);
              }
            
  	   }
  	   catch(Exception ex)
         {
             System.out.println("!!!!"+ex.getMessage());
         }
  	   return liste;
    }
    
	public ArrayList<Article> listArticlesCat(Integer idCat)
	{
		ArrayList<Article> liste = new ArrayList<Article>();	
		   try
		   {
			   st= con.prepareStatement("select * from Article where categorie=?");
	        st.setInt(1, idCat);
	        rs=st.executeQuery();
	        while(rs.next())
            {
             int id=rs.getInt("id");
              String titre=rs.getString("titre");
              String contenu=rs.getString("contenu");
              Integer cat =  rs.getInt("categorie");
              Date dateCrea = rs.getDate("dateCreation");
              Date dateModif = rs.getDate("dateModification");
              Article ar = new Article(id, titre, contenu, cat, dateCrea, dateModif);
              liste.add(ar);
             }
		   }
		   catch(Exception ex)
	    {
	        System.out.println("!!!!"+ex.getMessage());
	    }
		   return liste;
	}
	
	
	
	public ArrayList<Article> listArticlesParCat()
	{
		ArrayList<Article> liste = new ArrayList<Article>();	
		   try
		   {
			   st= con.prepareStatement("select * from Article,Categorie where categorie=Categorie.id order by categorie");
	        //st.setInt(1, idCat);
	        rs=st.executeQuery();
	        while(rs.next())
            {
             int id=rs.getInt("id");
              String titre=rs.getString("titre");
              String contenu=rs.getString("contenu");
              Integer cat =  rs.getInt("categorie");
              Date dateCrea = rs.getDate("dateCreation");
              Date dateModif = rs.getDate("dateModification");
              Article a = new Article(id, titre, contenu, cat, dateCrea, dateModif);
              liste.add(a);
             }
		   }
		   catch(Exception ex)
	    {
	        System.out.println("!!!!"+ex.getMessage());
	    }
		   return liste;
	}
	
}
