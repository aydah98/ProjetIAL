package service;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;


import dao.AccesBD;
import domaine.Article;

@Path("/actualites")
public class ArticleService {
	private AccesBD bd  = new AccesBD(); 
	
	@GET
	@Path("/articles/")
	//@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Article> listArticles(){
		ArrayList<Article> liste = bd.listArticles();
		return liste;
	} 
	
	@GET
	@Path("/articles/categories/{idCat}")
	//@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Article> listArticlesCat(@PathParam(value="idCat")Integer idCat){
		ArrayList<Article> liste = bd.listArticlesCat(idCat);
		return liste;
	} 
	
	@GET
	@Path("/articles/parCategorie}")
	//@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Article> listArticlesCat(){
		ArrayList<Article> liste = bd.listArticlesParCat();
		return liste;
	} 
}
