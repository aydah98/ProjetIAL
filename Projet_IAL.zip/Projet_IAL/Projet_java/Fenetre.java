import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.beans.Statement;
import java.sql.PreparedStatement;
import java.sql.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import proj.GestionUtilisateurWs;
import proj.GestionUtilisateurWsService;
import proj.AuthentificationResponse;
import proj.Authentification;


public class Fenetre extends JFrame implements ActionListener{
  public JPanel panel;

  private JButton bouton;
	private JButton bouton2;
  public JTextField login;
  public JTextField pass;
  public JButton connecter;
  public JLabel log,pas;

	//...

  public Fenetre () {
		panel = new JPanel();

    Container contenu=this.getContentPane();
    contenu.add(panel);
    panel.add(new JLabel("login:"));
    panel.add(login=new JTextField(20));

    panel.add(new JLabel("Password:"));
    panel.add(pass=new JTextField(20));
    panel.add(connecter=new JButton("Connecter"));

    connecter.addActionListener(this);
    this.setVisible(true);

	}

	public void actionPerformed(ActionEvent e) {

    Object source = e.getSource();
    if(source == connecter){
    /*  GestionUtilisateurWs clientWs=new GestionUtilisateurWsService().getGestionUtilisateurWsPort();
         String l = login.getText();
         String p = pass.getText();*/

        // if (clientWs.authentification(l,p)) {}
           Utilisateur fenetre=new Utilisateur();
           fenetre.setVisible(true);


         /*else {
           System.out.println("Informations incorrectes");

         }*/

		}
  	}

  public static void main(String[] args) {

    Fenetre fen=new Fenetre();
    fen.setVisible(true);
  }
}
