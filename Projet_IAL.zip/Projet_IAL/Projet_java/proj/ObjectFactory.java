
package proj;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the proj package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ModifieUtilisateur_QNAME = new QName("http://service/", "modifieUtilisateur");
    private final static QName _SupprimeUtilisateur_QNAME = new QName("http://service/", "supprimeUtilisateur");
    private final static QName _SupprimeUtilisateurResponse_QNAME = new QName("http://service/", "supprimeUtilisateurResponse");
    private final static QName _Authentification_QNAME = new QName("http://service/", "authentification");
    private final static QName _ListUtilisateur_QNAME = new QName("http://service/", "listUtilisateur");
    private final static QName _AuthentificationResponse_QNAME = new QName("http://service/", "authentificationResponse");
    private final static QName _AjoutUtilisateur_QNAME = new QName("http://service/", "ajoutUtilisateur");
    private final static QName _ModifieUtilisateurResponse_QNAME = new QName("http://service/", "modifieUtilisateurResponse");
    private final static QName _AjoutUtilisateurResponse_QNAME = new QName("http://service/", "ajoutUtilisateurResponse");
    private final static QName _ListUtilisateurResponse_QNAME = new QName("http://service/", "listUtilisateurResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: proj
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ModifieUtilisateurResponse }
     * 
     */
    public ModifieUtilisateurResponse createModifieUtilisateurResponse() {
        return new ModifieUtilisateurResponse();
    }

    /**
     * Create an instance of {@link AjoutUtilisateur }
     * 
     */
    public AjoutUtilisateur createAjoutUtilisateur() {
        return new AjoutUtilisateur();
    }

    /**
     * Create an instance of {@link AuthentificationResponse }
     * 
     */
    public AuthentificationResponse createAuthentificationResponse() {
        return new AuthentificationResponse();
    }

    /**
     * Create an instance of {@link Authentification }
     * 
     */
    public Authentification createAuthentification() {
        return new Authentification();
    }

    /**
     * Create an instance of {@link ListUtilisateur }
     * 
     */
    public ListUtilisateur createListUtilisateur() {
        return new ListUtilisateur();
    }

    /**
     * Create an instance of {@link ModifieUtilisateur }
     * 
     */
    public ModifieUtilisateur createModifieUtilisateur() {
        return new ModifieUtilisateur();
    }

    /**
     * Create an instance of {@link SupprimeUtilisateur }
     * 
     */
    public SupprimeUtilisateur createSupprimeUtilisateur() {
        return new SupprimeUtilisateur();
    }

    /**
     * Create an instance of {@link SupprimeUtilisateurResponse }
     * 
     */
    public SupprimeUtilisateurResponse createSupprimeUtilisateurResponse() {
        return new SupprimeUtilisateurResponse();
    }

    /**
     * Create an instance of {@link AjoutUtilisateurResponse }
     * 
     */
    public AjoutUtilisateurResponse createAjoutUtilisateurResponse() {
        return new AjoutUtilisateurResponse();
    }

    /**
     * Create an instance of {@link ListUtilisateurResponse }
     * 
     */
    public ListUtilisateurResponse createListUtilisateurResponse() {
        return new ListUtilisateurResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModifieUtilisateur }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "modifieUtilisateur")
    public JAXBElement<ModifieUtilisateur> createModifieUtilisateur(ModifieUtilisateur value) {
        return new JAXBElement<ModifieUtilisateur>(_ModifieUtilisateur_QNAME, ModifieUtilisateur.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupprimeUtilisateur }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "supprimeUtilisateur")
    public JAXBElement<SupprimeUtilisateur> createSupprimeUtilisateur(SupprimeUtilisateur value) {
        return new JAXBElement<SupprimeUtilisateur>(_SupprimeUtilisateur_QNAME, SupprimeUtilisateur.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SupprimeUtilisateurResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "supprimeUtilisateurResponse")
    public JAXBElement<SupprimeUtilisateurResponse> createSupprimeUtilisateurResponse(SupprimeUtilisateurResponse value) {
        return new JAXBElement<SupprimeUtilisateurResponse>(_SupprimeUtilisateurResponse_QNAME, SupprimeUtilisateurResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Authentification }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "authentification")
    public JAXBElement<Authentification> createAuthentification(Authentification value) {
        return new JAXBElement<Authentification>(_Authentification_QNAME, Authentification.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListUtilisateur }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "listUtilisateur")
    public JAXBElement<ListUtilisateur> createListUtilisateur(ListUtilisateur value) {
        return new JAXBElement<ListUtilisateur>(_ListUtilisateur_QNAME, ListUtilisateur.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AuthentificationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "authentificationResponse")
    public JAXBElement<AuthentificationResponse> createAuthentificationResponse(AuthentificationResponse value) {
        return new JAXBElement<AuthentificationResponse>(_AuthentificationResponse_QNAME, AuthentificationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AjoutUtilisateur }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "ajoutUtilisateur")
    public JAXBElement<AjoutUtilisateur> createAjoutUtilisateur(AjoutUtilisateur value) {
        return new JAXBElement<AjoutUtilisateur>(_AjoutUtilisateur_QNAME, AjoutUtilisateur.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModifieUtilisateurResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "modifieUtilisateurResponse")
    public JAXBElement<ModifieUtilisateurResponse> createModifieUtilisateurResponse(ModifieUtilisateurResponse value) {
        return new JAXBElement<ModifieUtilisateurResponse>(_ModifieUtilisateurResponse_QNAME, ModifieUtilisateurResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AjoutUtilisateurResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "ajoutUtilisateurResponse")
    public JAXBElement<AjoutUtilisateurResponse> createAjoutUtilisateurResponse(AjoutUtilisateurResponse value) {
        return new JAXBElement<AjoutUtilisateurResponse>(_AjoutUtilisateurResponse_QNAME, AjoutUtilisateurResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListUtilisateurResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service/", name = "listUtilisateurResponse")
    public JAXBElement<ListUtilisateurResponse> createListUtilisateurResponse(ListUtilisateurResponse value) {
        return new JAXBElement<ListUtilisateurResponse>(_ListUtilisateurResponse_QNAME, ListUtilisateurResponse.class, null, value);
    }

}
