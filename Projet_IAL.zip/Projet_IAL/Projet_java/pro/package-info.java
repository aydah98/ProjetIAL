@javax.xml.bind.annotation.XmlSchema(namespace = "http://service/")
package pro;
