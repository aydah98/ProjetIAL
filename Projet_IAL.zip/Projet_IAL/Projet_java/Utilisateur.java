import javax.swing.*;
import java.awt.*;
import java.beans.Statement;
import java.sql.PreparedStatement;
import java.sql.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.beans.Statement;
import proj.GestionUtilisateurWs;
import proj.GestionUtilisateurWsService;
import proj.AuthentificationResponse;
import proj.Authentification;


public class Utilisateur extends JFrame implements ActionListener{
  /* Chargement du driver JDBC pour MySQL */

  public JPanel panel;
  public JTextField login;
  public JTextField pass;
  public JButton ajouter,modifier,supprimer,lister;
  public JLabel log,pas;
   Connection con=null;
   Statement stmt = null;
   ResultSet rs;

  public Utilisateur ()  {
    super("Page Authentification");
    panel = new JPanel();

     Container contenu=this.getContentPane();

     contenu.add(panel);
     panel.add(ajouter=new JButton("ajouter"));
     panel.add(modifier=new JButton("modifier"));
     panel.add(supprimer=new JButton("supprimer"));
     panel.add(lister=new JButton("lister"));

     ajouter.addActionListener(this);
     this.setVisible(true);


  }
  public void actionPerformed(ActionEvent e) {
    GestionUtilisateurWs clientWs=new GestionUtilisateurWsService().getGestionUtilisateurWsPort();

    Object source = e.getSource();
    if(source == ajouter){
         String l =new String("kine");
         String p=new String("khouma") ;

         clientWs.ajoutUtilisateur(l,p);
    }
   if(source == modifier){
         String l =new String("MameDiarra");
         String p=new String("Ngo") ;

         clientWs.modifieUtilisateur(1,l,p);
    }
  if (source == supprimer) {
    int valeur1=2;
    clientWs.supprimeUtilisateur(valeur1);

  }
  if (source == lister){
    clientWs.listUtilisateur();

  }

  }

  public static void main(String[] args) throws SQLException, ClassNotFoundException {
    Utilisateur fenetre=new Utilisateur();
  }


}
