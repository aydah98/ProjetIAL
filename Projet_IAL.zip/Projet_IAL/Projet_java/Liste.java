import javax.swing.*;
import java.awt.*;
import java.beans.Statement;
import java.sql.PreparedStatement;
import java.sql.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.beans.Statement;
import proj.GestionUtilisateurWs;
import proj.GestionUtilisateurWsService;
import proj.AuthentificationResponse;
import proj.Authentification;

public class Liste  extends JFrame implements ActionListener {
  public JPanel panel;

  public Liste(){
    super(" Liste des utilisateurs");
    panel = new JPanel();
     Container contenu=this.getContentPane();
     contenu.add(panel);
     this.setVisible(true);


    }
    public void actionPerformed(ActionEvent e) {
      GestionUtilisateurWs clientWs=new GestionUtilisateurWsService().getGestionUtilisateurWsPort();
      clientWs.listUtilisateur();
   }


public static void main(String[] args) {
  Liste li=new Liste();
}
}
