<?php include 'connexiondb/db.php'; ?>
<!DOCTYPE html>
<html lang="fr">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Actualites MGLSI</title>

  <?php require_once 'style.html' ?>

</head>

<body>

  <?php 

    require_once 'accueil/nav.php';


	if(isset($_GET['action'])){
		if(!isset($_GET['id'])){
			if($_GET['action'] == "ajouterArticle"){

				require_once 'site/ajouterArticle.php';
			}
			else if($_GET['action'] == "ajouterCategorie"){

				require_once 'site/ajouterCategorie.php';
			}else
				echo "<p style='color: red;'>Erreur !!!!!!</p>";
		}else{
			if($_GET['action'] == "modifierArticle"){

				require_once 'site/modifierArticle.php';
			}
			if($_GET['action'] == "modifierCategorie"){

				require_once 'site/modifierCategorie.php';

			}if($_GET['action'] == "supprimerCategorie"){

				require_once 'site/supprimerCategorie.php';

			}if($_GET['action'] == "supprimerArticle"){

				require_once 'site/supprimerArticle.php';

			}
		} 
	}
 ?>


</body>

</html>


