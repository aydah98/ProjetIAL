<?php include 'connexiondb/db.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Actualites MGLSI</title>

  <?php require_once 'style.html' ?>

</head>

<body>

  <?php 

    require_once 'accueil/nav.php';
    require_once 'accueil/header.php';

   ?>



   <?php 

    if(isset($_GET['id']) && !empty($_GET['id'])){
      $reponse = $conn->query('SELECT * FROM Article where categorie='.$_GET['id']);
      
      //if(!empty($article)){
    ?>

    <!-- Main Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        <?php while($article = $reponse->fetch()) { ?>
        <div class="post-preview">
          <a href="afficherArticle.php?id=<?= $article['id'] ?>">
            <h2 class="post-title">
              <?php echo $article['titre']; ?>
            </h2>
            <h3 class="post-subtitle">
              <p><?= substr($article['contenu'], 0, 100) . '...' ?></p>
            </h3>
           </a>
          <p class="post-meta">Publié le <?php echo $article['dateCreation']; ?></p>
          
        </div>
      <?php } 
        }else
          echo '<p style="color: red;">Erreur !!!!!!!</p>';
        /*}else
          echo '<p style=\"color: red;\">Erreur !!!!!!!</p>';*/
      ?>
        <hr>
        <!-- Pager -->
        <div class="clearfix">
          <a class="btn btn-primary float-right" href="index2.html">suivant &rarr;</a>
        </div>
      </div>
    </div>
  </div>



<hr>


  

</body>

</html>
