<?php 

	$message = "";

	if(isset($_POST['libelle']) && !empty($_POST['libelle'])){
		$reponse = $conn->prepare('insert into Categorie(libelle) value(?)');
		$reponse->execute(array($_POST['libelle']));
		$message = "Categorie ajouté";
	}else
		$message = "veuillez remplir tous les champs";

 ?>

   <!-- Main Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        <p>Ajouter un nouveau Categorie</p>
       	<p style="color: red;"><?php echo $message; ?></p>
        <form name="sentMessage" id="contactForm" novalidate method="POST">
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Libelle</label>
              <input type="text" name="libelle" class="form-control" placeholder="Libelle" id="name" required data-validation-required-message="Please enter your name.">
              <p class="help-block text-danger"></p>
            </div>
          </div>
          
          <br>
          <div id="success"></div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary" id="sendMessageButton">Enregistrer</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <hr>