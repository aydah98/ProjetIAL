<?php 

	$reponse1 = $conn->prepare('delete from Article where id=?');
	$reponse1->execute(array($_GET['id']));
	header('Location: gestionsSite.php');
 ?>