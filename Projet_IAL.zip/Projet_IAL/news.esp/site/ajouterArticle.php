<?php 

	$message = "";

	if(isset($_POST['titre']) && !empty($_POST['titre']) && isset($_POST['contenu']) && !empty($_POST['contenu'])){
		$reponse = $conn->prepare('insert into Article(titre, contenu) value(?,?)');
		$reponse->execute(array($_POST['titre'], $_POST['contenu']));
		$message = "Article ajouter";
	}else
		$message = "veuillez remplir tous les champs";

 ?>

   <!-- Main Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        <p>Ajouter un nouveau Article</p>
       	<p style="color: red;"><?php echo $message; ?></p>
        <form name="sentMessage" id="contactForm" novalidate method="POST">
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Titre</label>
              <input type="text" name="titre" class="form-control" placeholder="Titre" id="name" required data-validation-required-message="Please enter your name.">
              <p class="help-block text-danger"></p>
            </div>
          </div>
          
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Contenu</label>
              <textarea rows="5" name="contenu" class="form-control" placeholder="Contenu" id="message" required data-validation-required-message="Please enter a message."></textarea>
              <p class="help-block text-danger"></p>
            </div>
          </div>

          <br>
          <div id="success"></div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary" id="sendMessageButton">Enregistrer</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <hr>