<?php 
    
    $reponse1 = $conn->query('select * from Categorie where id='.$_GET['id']);
    $categorie = $reponse1->fetch();

 ?>

<?php 

	$message = "";

	if(isset($_POST['libelle']) && !empty($_POST['libelle'])){
		$reponse = $conn->prepare('update Categorie set libelle='.$_POST['libelle'].' where id='.$_GET['id'].')');
		$reponse->execute(array($_POST['libelle'], $_GET['id']));
		$message = "Categorie modifier";
	}else
		$message = "veuillez remplir tous les champs";

 ?>

   <!-- Main Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        <p>Ajouter un nouveau Categorie</p>
       	<p style="color: red;"><?php echo $message; ?></p>
       	<?php if($categorie != null){ ?>
        <form name="sentMessage" id="contactForm" novalidate method="POST">
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Libelle</label>
              <input type="text" name="libelle" value="<?php echo $categorie['libelle']; ?>" class="form-control" placeholder="Titre" id="name" required data-validation-required-message="Please enter your name.">
              <p class="help-block text-danger"></p>
            </div>
          </div>
          
          <br>
          <div id="success"></div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary" id="sendMessageButton">Enregistrer</button>
          </div>
        </form>
    <?php 
		}else
			echo "<p style='color: red;'>Erreur !!!!!!</p>"
    	 ?>
      </div>
    </div>
  </div>

  <hr>