<?php 
  $data = $conn->query('SELECT * FROM Article');
  //$articles = $data->fetchAll(PDO::FETCH_CLASS, 'Article');

?>

  <!-- Main Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
        <?php while($article = $data->fetch()) { ?>
        <div class="post-preview">
          <a href="afficherArticle.php?id=<?= $article['id'] ?>">
            <h2 class="post-title">
              <?php echo $article['titre']; ?>
            </h2>
            <h3 class="post-subtitle">
              <p><?= substr($article['contenu'], 0, 100) . '...' ?></p>
            </h3>
          </a>
          <p class="post-meta">Publié le <?php echo $article['dateCreation']; ?></p>
          
        </div>
      <?php } ?>
        <hr>
        <!-- Pager -->
        
      </div>
    </div>
  </div>



<hr>
