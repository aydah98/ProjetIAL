<?php 

  
  $reponse = $conn->query('SELECT * FROM Categorie');
  //$categories = $reponse->fetch();
?>


<nav class="navbar navbar-expand-md navbar-light bg-light">
  <a class="navbar-brand" href="index.php">MGLSI NEWS</a>
  <ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-link" href="index.php">Accueil <span class="sr-only">Accueil</span></a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Catégories
      </a>
      <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
        <?php while($categorie = $reponse->fetch()){ ?>
          <a class="dropdown-item" href="articlesParCategorie.php?id=<?= $categorie['id'] ?>"><?php echo $categorie['libelle']; ?></a>
        <?php } ?>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="seconnecter.php">Se connecter</a>
    </li>
  </ul>
</nav>

  