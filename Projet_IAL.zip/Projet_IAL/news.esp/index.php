<?php include 'connexiondb/db.php'; ?>
<!DOCTYPE html>
<html lang="fr">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Actualites MGLSI</title>

  <?php require_once 'style.html' ?>

</head>

<body>

  <?php 

    require_once 'accueil/nav.php';
    require_once 'accueil/header.php';
    require_once 'accueil/listesArticles.php';

   ?>

  

</body>

</html>
