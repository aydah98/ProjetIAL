<!-- Main Content -->
  <?php 
  		$message = "";

  	if(isset($_POST['login']) && !empty($_POST['login']) && isset($_POST['password']) && !empty($_POST['password'])){

  		$client = new SoapClient('http://localhost:8080/GestionUtilisateurWs?wsdl');
  		$login = $_POST['login'];
  		$password = $_POST['password'];

			$param = array("arg0" => $login, "arg1" => $password);
			$verifier = $client->__soapCall('authentification', array($param));

			if($verifier != ""){

				header('Location: gestionsSite.php');
			}
			else
				$message = 'login ou password incorrect !!!!!!!';
  	}else
  		$message = 'Veuillez remplir tous les champs !!!!!!!';
   ?>

  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
      	
        <p>veuillez remplir login et password ci-aprés.</p>
       
        <form name="" id="contactForm" novalidate method="POST">
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Login</label>
              <input type="text" name="login" class="form-control" placeholder="Login" id="name" required data-validation-required-message="Please enter your name.">
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label>Password</label>
              <input type="password" name="password" class="form-control" placeholder="Password" id="email" required data-validation-required-message="Please enter your email address.">
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <br>
          <div id="success"></div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary" id="sendMessageButton">Connexion</button>
          </div>
        </form>
        <p style="color: red;"><?php echo $message; ?></p>
      </div>
    </div>
  </div>

  <hr>