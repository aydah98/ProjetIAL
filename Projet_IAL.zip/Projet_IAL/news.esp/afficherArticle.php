<?php include 'connexiondb/db.php'; ?>
<!DOCTYPE html>
<html lang="fr">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Actualites MGLSI</title>

  <?php require_once 'style.html' ?>

</head>

<body>

  <?php 

    require_once 'accueil/nav.php';
    require_once 'accueil/header.php';

   ?>


    <!-- Main Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">

        <?php 

            if(isset($_GET['id']) && !empty($_GET['id'])){
              $id = $_GET['id'];
              $reponse = $conn->prepare('SELECT * FROM Article where id=?');
              $reponse->bindParam(1, $id);
              $reponse->execute();
              $article = $reponse->fetch();
              //$reponse = $conn->query('SELECT * FROM Article where id='.$_GET['id']);*/
              $message = "";
              if($article != null){
        ?>
        <div class="post-preview">
            <h2 class="post-title">
              <?php echo $article['titre']; ?>
            </h2>
            <h3 class="post-subtitle">
              <p><?= $article['contenu']; ?></p>
            </h3>
          <p class="post-meta">Publié le <?php echo $article['dateCreation']; ?></p>
          
        </div>
      <?php  }else
               echo "<p style=\"color: red;\">Article introuvable !!!!!!!</p>";
      }else
        echo "<p style=\"color: red;\">Pas d'article  !!!!!!!</p>";

      ?>

        <hr>
        <!-- Pager -->
        <div class="clearfix">
          <a class="btn btn-primary float-right" href="index2.html">suivant &rarr;</a>
        </div>
      </div>
    </div>
  </div>



<hr>


  

</body>

</html>
