<?php include 'connexiondb/db.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Actualites MGLSI</title>

  <?php require_once 'style.html' ?>

</head>

<body>

  <?php 

    require_once 'accueil/nav.php';
    //require_once 'seconnecter/formulaire.php'
   ?>

   <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
      	
        <p>veuillez choisir le format de récupération des données </p>
       
        <form name="" id="contactForm" novalidate method="POST" action="">
          <div class="control-group">
            <div class="form-group floating-label-form-group controls">
              <label for="name"></label>
              <select name="format" class="form-control" placeholder="Login" id="name" required data-validation-required-message="Please enter your name.">
              	<option value="json">JSON</option>
              	<option value="xml">XML</option>
              </select>
              <p class="help-block text-danger"></p>
            </div>
          </div>
          <br>
          <div id="success"></div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary" id="sendMessageButton" name="categories">Gestions Categories</button>
            <button type="submit" class="btn btn-primary" id="sendMessageButton" name="articles">Gestions Articles</button>
          </div>
        </form>
       
        <hr>

         <?php 

	if(isset($_POST['categories']) && isset($_POST['format'])){
		$format = $_POST['format']; 
		if($format == "json"){
			$reponse = $conn->query('SELECT * FROM Categorie');

	 ?>	
	 <a type="" href="gererSite.php?action=ajouterCategorie" class="btn btn-primary" id="">Ajouter categorie</a><br><br>
	  <table class="table">
	    <thead class="thead-light">
	      <tr>
	        <th>ID</th>
	        <th>LIBELLE</th>
	        <th>ACTION</th>
	      </tr>
	    </thead>
	    <tbody>
	    <?php  
	 	while($categorie = $reponse->fetch()){ ?>
	      <tr>
	        <td><?php echo $categorie['id']; ?></td>
	        <td><?php echo $categorie['libelle']; ?></td>
	        <td>
	            	<a type="" class="btn btn-success" href="gererSite.php?action=modifierCategorie&id=<?php echo $categorie['id']; ?>" id="" style="align-self: left">modifier</a>
	            	<a type="" class="btn btn-danger" href="gererSite.php?action=supprimerArticle&id=<?php echo $categorie['id']; ?>" id="" style="align-self: left">supprimer</a>

	        </td>
	      </tr>
	      <?php } ?>
	    </tbody>
	  </table>

	 <?php	
		}
	}
	if(isset($_POST['articles']) && isset($_POST['format'])){
		$format = $_POST['format']; 
		if($format == "json"){
			$reponse = $conn->query('SELECT * FROM Article');

	 ?>	
	 <a type="" href="gererSite.php?action=ajouterArticle"class="btn btn-primary" id="">Ajouter Article</a><br><br>
	  <table class="table">
	    <thead class="thead-light">
	      <tr>
	        <th>ID</th>
	        <th>TITRE</th>
	        <th>CONTENU</th>
	        <th>ACTION</th>
	      </tr>
	    </thead>
	    <tbody>
	    <?php  
	 	while($article = $reponse->fetch()){ ?>
	      <tr>
	        <td><?php echo $article['id']; ?></td>
	        <td><?php echo $article['titre']; ?></td>
	        <td><?php echo substr($article['contenu'], 0, 20) . '...' ?></td>
	        <td>
	            	<a type="" href="gererSite.php?action=modifierArticle&id=<?php echo $article['id']; ?>" class="btn btn-success" id="" style="align-self: left">modifier</a>
	            	<a type="" href="gererSite.php?action=supprimerArticle&id=<?php echo $article['id']; ?>" class="btn btn-danger" id="" style="align-self: left">supprimer</a>

	        </td>
	      </tr>
	      <?php } ?>
	    </tbody>
	  </table>

	 <?php	
		}
	}
 ?>

      </div>
    </div>
    
  </div>

  <hr>

  

</body>

</html>

